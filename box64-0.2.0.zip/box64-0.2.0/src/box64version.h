#ifndef __BOX64_VERSION_H_
#define __BOX64_VERSION_H_

#define BOX64_MAJOR 0
#define BOX64_MINOR 2
#define BOX64_REVISION 0

#endif //__BOX64_VERSION_H_
